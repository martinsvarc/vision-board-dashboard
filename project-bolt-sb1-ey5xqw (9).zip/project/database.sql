-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create users table
CREATE TABLE users (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  member_id VARCHAR(255) UNIQUE NOT NULL,
  email VARCHAR(255),
  team_id VARCHAR(255),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create sessions table
CREATE TABLE sessions (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  session_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  points INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create streaks table
CREATE TABLE streaks (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  current_streak INTEGER DEFAULT 0,
  longest_streak INTEGER DEFAULT 0,
  last_session_date DATE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create achievements table
CREATE TABLE achievements (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  achievement_type VARCHAR(50) NOT NULL,
  achievement_level INTEGER NOT NULL,
  unlocked_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, achievement_type, achievement_level)
);

-- Create league_rankings table
CREATE TABLE league_rankings (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  points INTEGER DEFAULT 0,
  rank INTEGER,
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  ranking_type VARCHAR(50) NOT NULL, -- 'weekly', 'all_time', 'team'
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, period_start, period_end, ranking_type)
);

-- Create improvement_plans table
CREATE TABLE improvement_plans (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  action_item TEXT NOT NULL,
  completed BOOLEAN DEFAULT FALSE,
  due_date DATE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create areas_of_improvement table
CREATE TABLE areas_of_improvement (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  area TEXT NOT NULL,
  priority INTEGER NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create vision_items table
CREATE TABLE vision_items (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  src TEXT NOT NULL,
  x DECIMAL(10,2) NOT NULL,
  y DECIMAL(10,2) NOT NULL,
  width DECIMAL(10,2) NOT NULL,
  height DECIMAL(10,2) NOT NULL,
  z_index INTEGER NOT NULL,
  aspect_ratio DECIMAL(10,6) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes
CREATE INDEX idx_sessions_user_date ON sessions(user_id, session_date);
CREATE INDEX idx_streaks_user ON streaks(user_id);
CREATE INDEX idx_achievements_user ON achievements(user_id);
CREATE INDEX idx_league_rankings_user_period ON league_rankings(user_id, period_start, period_end);
CREATE INDEX idx_improvement_plans_user ON improvement_plans(user_id);
CREATE INDEX idx_areas_improvement_user ON areas_of_improvement(user_id);
CREATE INDEX idx_vision_items_user ON vision_items(user_id);

-- Create functions for updating timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers
CREATE TRIGGER update_streaks_updated_at
  BEFORE UPDATE ON streaks
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_league_rankings_updated_at
  BEFORE UPDATE ON league_rankings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_areas_improvement_updated_at
  BEFORE UPDATE ON areas_of_improvement
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_vision_items_updated_at
  BEFORE UPDATE ON vision_items
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Function to calculate and update streaks
CREATE OR REPLACE FUNCTION calculate_streak(user_uuid UUID)
RETURNS void AS $$
DECLARE
  last_session DATE;
  current_streak INTEGER := 0;
  longest_streak INTEGER;
BEGIN
  -- Get the last session date
  SELECT MAX(DATE(session_date))
  INTO last_session
  FROM sessions
  WHERE user_id = user_uuid;

  -- Calculate current streak
  WITH RECURSIVE dates AS (
    SELECT last_session as date
    UNION ALL
    SELECT date - 1
    FROM dates
    WHERE EXISTS (
      SELECT 1
      FROM sessions
      WHERE user_id = user_uuid
      AND DATE(session_date) = date - 1
    )
  )
  SELECT COUNT(*)
  INTO current_streak
  FROM dates;

  -- Get longest streak
  SELECT COALESCE(longest_streak, current_streak)
  INTO longest_streak
  FROM streaks
  WHERE user_id = user_uuid;

  IF longest_streak IS NULL OR current_streak > longest_streak THEN
    longest_streak := current_streak;
  END IF;

  -- Update streaks table
  INSERT INTO streaks (user_id, current_streak, longest_streak, last_session_date)
  VALUES (user_uuid, current_streak, longest_streak, last_session)
  ON CONFLICT (user_id)
  DO UPDATE SET
    current_streak = EXCLUDED.current_streak,
    longest_streak = EXCLUDED.longest_streak,
    last_session_date = EXCLUDED.last_session_date,
    updated_at = CURRENT_TIMESTAMP;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update streaks after session insert
CREATE OR REPLACE FUNCTION update_streaks_after_session()
RETURNS TRIGGER AS $$
BEGIN
  PERFORM calculate_streak(NEW.user_id);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_streaks_after_session
AFTER INSERT ON sessions
FOR EACH ROW
EXECUTE FUNCTION update_streaks_after_session();