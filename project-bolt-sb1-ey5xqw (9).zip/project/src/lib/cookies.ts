interface CookieOptions {
  path?: string;
  maxAge?: number;
  secure?: boolean;
  sameSite?: 'Strict' | 'Lax' | 'None';
}

export const cookies = {
  get(name: string): string | undefined {
    const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
    return match ? decodeURIComponent(match[2]) : undefined;
  },

  set(name: string, value: string, options: CookieOptions = {}) {
    let cookie = `${name}=${encodeURIComponent(value)}`;
    
    if (options.path) cookie += `;path=${options.path}`;
    if (options.maxAge) cookie += `;max-age=${options.maxAge}`;
    if (options.secure) cookie += ';secure';
    if (options.sameSite) cookie += `;samesite=${options.sameSite}`;
    
    document.cookie = cookie;
  },

  remove(name: string, options: CookieOptions = {}) {
    this.set(name, '', { ...options, maxAge: -1 });
  }
};