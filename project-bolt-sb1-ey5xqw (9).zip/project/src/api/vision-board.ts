import { supabase } from '@/lib/supabase';

interface VisionItem {
  id: string;
  user_id: string;
  src: string;
  x: number;
  y: number;
  width: number;
  height: number;
  z_index: number;
  aspect_ratio: number;
  created_at: Date;
  updated_at: Date;
}

export async function getVisionItems(userId: string): Promise<VisionItem[]> {
  const { data, error } = await supabase
    .from('vision_items')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data || [];
}

export async function saveVisionItem(userId: string, item: {
  src: string;
  x: number;
  y: number;
  width: number;
  height: number;
  zIndex: number;
  aspectRatio: number;
}): Promise<VisionItem> {
  const { data, error } = await supabase
    .from('vision_items')
    .insert([{
      user_id: userId,
      src: item.src,
      x: item.x,
      y: item.y,
      width: item.width,
      height: item.height,
      z_index: item.zIndex,
      aspect_ratio: item.aspectRatio
    }])
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function updateVisionItem(
  itemId: string,
  userId: string,
  updates: Partial<{
    x: number;
    y: number;
    width: number;
    height: number;
    zIndex: number;
  }>
): Promise<VisionItem> {
  const { data, error } = await supabase
    .from('vision_items')
    .update({
      ...(updates.x !== undefined && { x: updates.x }),
      ...(updates.y !== undefined && { y: updates.y }),
      ...(updates.width !== undefined && { width: updates.width }),
      ...(updates.height !== undefined && { height: updates.height }),
      ...(updates.zIndex !== undefined && { z_index: updates.zIndex })
    })
    .eq('id', itemId)
    .eq('user_id', userId)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function deleteVisionItem(itemId: string, userId: string): Promise<void> {
  const { error } = await supabase
    .from('vision_items')
    .delete()
    .eq('id', itemId)
    .eq('user_id', userId);

  if (error) throw error;
}