import { query } from '@/lib/db';

export interface CallLog {
  id: string;
  member_id: string;
  call_number: number;
  user_name: string;
  agent_name: string;
  agent_picture_url: string;
  user_picture_url: string;
  call_recording_url: string;
  call_details: string;
  call_date: string;
  scores: {
    engagement: number;
    objection_handling: number;
    information_gathering: number;
    program_explanation: number;
    closing_skills: number;
    overall_effectiveness: number;
    average_success: number;
  };
  feedback: {
    engagement: string;
    objection_handling: string;
    information_gathering: string;
    program_explanation: string;
    closing_skills: string;
    overall_effectiveness: string;
  };
}

export async function getCallLogs(memberId: string): Promise<CallLog[]> {
  const result = await query(
    'SELECT * FROM call_logs WHERE member_id = $1 ORDER BY call_date DESC',
    [memberId]
  );

  return result.rows.map(row => ({
    id: row.id,
    member_id: row.member_id,
    call_number: row.call_number,
    user_name: row.user_name,
    agent_name: row.agent_name,
    agent_picture_url: row.agent_picture_url,
    user_picture_url: row.user_picture_url,
    call_recording_url: row.call_recording_url,
    call_details: row.call_details,
    call_date: row.call_date,
    scores: {
      engagement: parseFloat(row.engagement_score),
      objection_handling: parseFloat(row.objection_handling_score),
      information_gathering: parseFloat(row.information_gathering_score),
      program_explanation: parseFloat(row.program_explanation_score),
      closing_skills: parseFloat(row.closing_skills_score),
      overall_effectiveness: parseFloat(row.overall_effectiveness_score),
      average_success: parseFloat(row.average_success_score)
    },
    feedback: {
      engagement: row.engagement_feedback,
      objection_handling: row.objection_handling_feedback,
      information_gathering: row.information_gathering_feedback,
      program_explanation: row.program_explanation_feedback,
      closing_skills: row.closing_skills_feedback,
      overall_effectiveness: row.overall_effectiveness_feedback
    }
  }));
}

export async function createCallLog(memberId: string, data: Omit<CallLog, 'id'>): Promise<CallLog> {
  const result = await query(
    `INSERT INTO call_logs (
      member_id, call_number, user_name, agent_name, agent_picture_url,
      user_picture_url, call_recording_url, call_details,
      engagement_score, objection_handling_score, information_gathering_score,
      program_explanation_score, closing_skills_score, overall_effectiveness_score,
      average_success_score, engagement_feedback, objection_handling_feedback,
      information_gathering_feedback, program_explanation_feedback,
      closing_skills_feedback, overall_effectiveness_feedback
    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21)
    RETURNING *`,
    [
      memberId,
      data.call_number,
      data.user_name,
      data.agent_name,
      data.agent_picture_url,
      data.user_picture_url,
      data.call_recording_url,
      data.call_details,
      data.scores.engagement,
      data.scores.objection_handling,
      data.scores.information_gathering,
      data.scores.program_explanation,
      data.scores.closing_skills,
      data.scores.overall_effectiveness,
      data.scores.average_success,
      data.feedback.engagement,
      data.feedback.objection_handling,
      data.feedback.information_gathering,
      data.feedback.program_explanation,
      data.feedback.closing_skills,
      data.feedback.overall_effectiveness
    ]
  );

  return result.rows[0];
}

export async function updateCallLog(id: string, memberId: string, updates: Partial<CallLog>): Promise<CallLog> {
  const setClause = Object.keys(updates)
    .map((key, index) => `${key} = $${index + 3}`)
    .join(', ');

  const result = await query(
    `UPDATE call_logs 
     SET ${setClause}
     WHERE id = $1 AND member_id = $2
     RETURNING *`,
    [id, memberId, ...Object.values(updates)]
  );

  return result.rows[0];
}

export async function deleteCallLog(id: string, memberId: string): Promise<void> {
  await query(
    'DELETE FROM call_logs WHERE id = $1 AND member_id = $2',
    [id, memberId]
  );
}