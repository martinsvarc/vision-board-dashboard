import React from 'react';
import { useSearchParams } from 'react-router-dom';
import { useAuth } from './components/AuthProvider';
import VisionBoard from './components/VisionBoard';
import League from './components/League';
import CalendarStreak from './components/CalendarStreak';
import ActivityCircles from './components/ActivityCircles';
import AreasOfImprovement from './components/AreasOfImprovement';
import DailyPersonalizedImprovementPlan from './components/DailyPersonalizedImprovementPlan';
import AchievementShowcase from './components/AchievementShowcase';
import { Loader2 } from 'lucide-react';

function LoadingScreen() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#f0f1f7]">
      <Loader2 className="h-8 w-8 animate-spin text-[#556bc7]" />
    </div>
  );
}

function ErrorScreen() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#f0f1f7]">
      <div className="text-center">
        <h1 className="text-2xl font-bold text-[#556bc7] mb-4">Access Error</h1>
        <p className="text-gray-600">Unable to verify access. Please refresh the page.</p>
      </div>
    </div>
  );
}

export default function App() {
  const { memberId, loading } = useAuth();
  const [searchParams] = useSearchParams();
  const component = searchParams.get('component');

  if (loading) {
    return <LoadingScreen />;
  }

  if (!memberId) {
    return <ErrorScreen />;
  }

  // Render component based on URL parameter
  switch (component) {
    case 'vision-board':
      return <VisionBoard />;
    case 'league':
      return <League />;
    case 'calendar':
      return <CalendarStreak />;
    case 'activity-circles':
      return <ActivityCircles />;
    case 'improvement':
      return <AreasOfImprovement />;
    case 'plan':
      return <DailyPersonalizedImprovementPlan />;
    case 'achievement':
      return <AchievementShowcase />;
    default:
      return <ErrorScreen />;
  }
}